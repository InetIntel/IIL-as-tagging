# Snapshot Schema (2025-12)

- Schema version: `v1`
- Generated at (UTC): `2026-01-22T22:21:22.101449+00:00`
- Complex fields stored as JSON strings: `True`

| Field | Logical type | Storage type | Default | Encoding |
| --- | --- | --- | --- | --- |
| asn | int | int64 |  |  |
| LACeS-anycast_v4_cnt | float | float | 0.0 |  |
| LACeS-anycast_v6_cnt | float | float | 0.0 |  |
| apnic-eyeball_cc_cnt | float | float | 0.0 |  |
| apnic-eyeball_eyeball_cnt | float | float | 0.0 |  |
| apnic-eyeball_gini | float | float | 0.0 |  |
| apnic-eyeball_top_cc(frac) | string | string |  |  |
| apnic-eyeball_top_cc(num) | string | string |  |  |
| apnic-eyeball_top_frac | float | float | 0.0 |  |
| caida-asrel_cone_/24_cnt | float | float | 0.0 |  |
| caida-asrel_cone_/64_cnt | float | float | 0.0 |  |
| caida-asrel_cone_as_cnt | int | int | 0 |  |
| caida-asrel_cone_as_list | list | string | [] | json |
| caida-asrel_customer_cnt | int | int | 0 |  |
| caida-asrel_customer_list | list | string | [] | json |
| caida-asrel_peer_cnt | int | int | 0 |  |
| caida-asrel_peer_list | list | string | [] | json |
| caida-asrel_provider_cnt | int | int | 0 |  |
| caida-asrel_provider_list | list | string | [] | json |
| caida-itdk_cc_cnt | int | int | 0 |  |
| caida-itdk_cc_cnt_v4 | int | int | 0 |  |
| caida-itdk_cc_cnt_v6 | int | int | 0 |  |
| caida-itdk_gini | float | float | 0.0 |  |
| caida-itdk_gini_v4 | float | float | 0.0 |  |
| caida-itdk_gini_v6 | float | float | 0.0 |  |
| caida-itdk_router_cnt | int | int | 0 |  |
| caida-itdk_router_cnt_v4 | int | int | 0 |  |
| caida-itdk_router_cnt_v6 | int | int | 0 |  |
| caida-itdk_topcc | string | string |  |  |
| caida-itdk_topcc_v4 | string | string |  |  |
| caida-itdk_topcc_v6 | string | string |  |  |
| caida-itdk_topfrac | float | float | 0.0 |  |
| caida-itdk_topfrac_v4 | float | float | 0.0 |  |
| caida-itdk_topfrac_v6 | float | float | 0.0 |  |
| censys_auth_cnt | float | float | 0.0 |  |
| censys_fdnsname_cnt | float | float | 0.0 |  |
| censys_forw_cnt | float | float | 0.0 |  |
| censys_http_cnt | float | float | 0.0 |  |
| censys_ics_cnt | float | float | 0.0 |  |
| censys_os_1_cnt | float | float | 0.0 |  |
| censys_os_1_name | string | string |  |  |
| censys_os_2_cnt | float | float | 0.0 |  |
| censys_os_2_name | string | string |  |  |
| censys_os_3_cnt | float | float | 0.0 |  |
| censys_os_3_name | string | string |  |  |
| censys_os_cnt | float | float | 0.0 |  |
| censys_port_1_cnt | float | float | 0.0 |  |
| censys_port_1_name | string | string |  |  |
| censys_port_2_cnt | float | float | 0.0 |  |
| censys_port_2_name | string | string |  |  |
| censys_port_3_cnt | float | float | 0.0 |  |
| censys_port_3_name | string | string |  |  |
| censys_port_cnt | float | float | 0.0 |  |
| censys_rdnsname_cnt | float | float | 0.0 |  |
| censys_recu_cnt | float | float | 0.0 |  |
| censys_service_1_cnt | float | float | 0.0 |  |
| censys_service_1_name | string | string |  |  |
| censys_service_2_cnt | float | float | 0.0 |  |
| censys_service_2_name | string | string |  |  |
| censys_service_3_cnt | float | float | 0.0 |  |
| censys_service_3_name | string | string |  |  |
| censys_service_cnt | float | float | 0.0 |  |
| censys_ssh_cnt | float | float | 0.0 |  |
| censys_v4addr_cnt | float | float | 0.0 |  |
| censys_voip_cnt | float | float | 0.0 |  |
| delegation_cc | string | string |  |  |
| delegation_rir | string | string |  |  |
| hg-offnet_v4addr_cnt | int | int | 0 |  |
| iij-hege_global_hege_v4 | float | float | 0.0 |  |
| iij-hege_global_hege_v6 | float | float | 0.0 |  |
| iij-tr-hege_ix_cnt | float | float | 0.0 |  |
| iij-tr-hege_ix_hegemony | float | float | 0.0 |  |
| iij-tr-hege_peers_cnt | float | float | 0.0 |  |
| inetintel-as2org_sibling_cnt | int | int | 0 |  |
| inetintel-as2org_sibling_list | list | string | [] | json |
| isi_/24_cnt | int | int | 0 |  |
| maxmind-geolite2_cc_v4_cnt | int | int | 0 |  |
| maxmind-geolite2_cc_v4_dict | dict | string | {} | json |
| maxmind-geolite2_cc_v6_cnt | int | int | 0 |  |
| maxmind-geolite2_cc_v6_dict | dict | string | {} | json |
| maxmind-geolite2_gini_v4 | float | float | 0.0 |  |
| maxmind-geolite2_gini_v6 | float | float | 0.0 |  |
| maxmind-geolite2_topcc_v4 | string | string |  |  |
| maxmind-geolite2_topcc_v6 | string | string |  |  |
| maxmind-geolite2_topfrac_v4 | float | float | 0.0 |  |
| maxmind-geolite2_topfrac_v6 | float | float | 0.0 |  |
| mlab-ndt_/24_cnt | int | int | 0 |  |
| mlab-ndt_/64_cnt | int | int | 0 |  |
| mlab-ndt_v4addr_cnt | int | int | 0 |  |
| mlab-ndt_v6addr_cnt | int | int | 0 |  |
| openintel-tranco_topdomain_cnt | float | float | 0.0 |  |
| openintel-tranco_v4addr_cnt | float | float | 0.0 |  |
| openintel-tranco_v6addr_cnt | float | float | 0.0 |  |
| pdb_ix_cnt | int | int | 0 |  |
| pdb_website | string | string |  |  |
| pfx2as_/24_cnt | float | float | 0.0 |  |
| pfx2as_/64_cnt | float | float | 0.0 |  |
